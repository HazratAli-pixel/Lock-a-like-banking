            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
<p >Copyright © 1983-2022  Central Bank of Thailand</p>
                        </div>
                    </div>
                </footer>
            </div>