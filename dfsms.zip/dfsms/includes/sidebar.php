        <nav class="hk-nav hk-nav-light">
            <a href="javascript:void(0);" id="hk_nav_close" class="hk-nav-close"><span class="feather-icon"><i data-feather="x"></i></span></a>
            <div class="nicescroll-bar">
                <div class="navbar-nav-wrap">
                    <ul class="navbar-nav flex-column">

                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="ion ion-ios-keypad"></i>
                                <span class="nav-link-text">Account Details</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <!-- <i class="ion ion-ios-keypad"></i>  -->
                                <img src="dist/img/send-money2.png" alt="user" style="width: 22px;" class="avatar-img">
                                <span class="nav-link-text ml-2 ">Send Money</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                            <img src="dist/img/money-transfer.png" alt="user" style="width: 20px;" class="avatar-img">
                                <span class="nav-link-text ml-2">Bank Transfer</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="cashout.php">
                            <img src="dist/img/send.jpg" alt="user" style="width: 25px;" class="avatar-img">
                                <span class="nav-link-text ml-5">Cash out</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                            <img src="dist/img/payment.png" alt="user" style="width: 22px;" class="avatar-img">
                                <span class="nav-link-text ml-2">Payment</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="deposit.php">
                            <img src="dist/img/deposit.png" alt="user" style="width: 22px;" class="avatar-img">
                                <span class="nav-link-text ml-2">Deposit</span>
                            </a>
                        </li>


                        <!-- <li class="nav-item">
                            <a class="nav-link" href="javascript:void(0);" data-toggle="collapse" data-target="#cats_drp">
                                <i class="ion ion-ios-copy"></i>
                                <span class="nav-link-text">Job Details</span>
                            </a>
                            <ul id="cats_drp" class="nav flex-column collapse collapse-level-1">
                                <li class="nav-item">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="add_job_list.php">Add Job info</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="manage-job.php">Manage Job info</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li> -->

                        </ul>
                 
                      
                      
                      
                  
                
                    <hr class="nav-separator">
            
                </div>
            </div>
        </nav>